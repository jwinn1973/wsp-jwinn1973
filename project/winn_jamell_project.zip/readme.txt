https://github.com/jwinn1973/wsp-jwinn1973.git

http://jwinn1973.github.com/wsp-jwinn1973/project//

I'm not missing 2 pages  I did 2 pages as pop up windows attached to the big buttons
on the home page.